create view smartphone_sales
            (posid, order_date, imei, employee_id, nomenclature, promotion, quantity, order_amount,
             order_amount_promotion, promotion_quantity, not_promotion_quantity, price, price_promotion, promotion_flag,
             employee_fio, region, address, supervisor, target_promotion, target_smartphones,
             target_promotion_by_period, target_smartphones_by_period)
as
SELECT s.posid,
       s.order_date,
       s.imei,
       s.employee_id,
       s.nomenclature,
       s.promotion,
       s.quantity,
       s.order_amount,
       s.order_amount_promotion,
       CASE
           WHEN s.promotion ~~ '%COMBO%'::text THEN s.quantity
           ELSE NULL::bigint
           END                                                 AS promotion_quantity,
       CASE
           WHEN s.promotion IS NULL THEN s.quantity
           ELSE NULL::bigint
           END                                                 AS not_promotion_quantity,
       s.order_amount / s.quantity::double precision           AS price,
       s.order_amount_promotion / s.quantity::double precision AS price_promotion,
       CASE
           WHEN s.promotion ~~ '%COMBO%'::text THEN 'комбо-акция'::text
           WHEN s.promotion IS NULL THEN 'без акции'::text
           ELSE NULL::text
           END                                                 AS promotion_flag,
       COALESCE(e.employee_fio, 'Продавец не определен'::text) AS employee_fio,
       st.region,
       st.address,
       st.supervisor,
       t.promotional_sales                                     AS target_promotion,
       t.smartphones                                           AS target_smartphones,
       tp.target_promotion_by_period,
       tp.target_smartphones_by_period
FROM smartphones s
         LEFT JOIN employees e ON s.employee_id = e.employee_id
         LEFT JOIN stores st ON s.posid = st.posid::double precision
         LEFT JOIN targets t ON s.posid = t.posid::double precision AND
                                date_trunc('month'::text, s.order_date) = t.reporting_period
         LEFT JOIN (SELECT targets.reporting_period,
                           sum(targets.promotional_sales) AS target_promotion_by_period,
                           sum(targets.smartphones)       AS target_smartphones_by_period
                    FROM targets
                    GROUP BY targets.reporting_period) tp
                   ON date_trunc('month'::text, s.order_date) = tp.reporting_period;

alter table smartphone_sales
    owner to daniildzheparov;

