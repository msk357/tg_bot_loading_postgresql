create view smartphones_sales_fact_target
            (region, address, supervisor, order_date, order_period, promotion_fact, not_promotion_fact,
             not_promotion_target, promotion_target, target_promotion_by_period, order_amount_promotin,
             avg_price_promotion)
as
SELECT smartphone_sales.region,
       smartphone_sales.address,
       smartphone_sales.supervisor,
       smartphone_sales.order_date::date                                                                       AS order_date,
       concat(
               CASE
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        1::double precision THEN 'Январь '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        2::double precision THEN 'Февраль '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        3::double precision THEN 'Март '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        4::double precision THEN 'Апрель '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        5::double precision THEN 'Май '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        6::double precision THEN 'Июнь '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        7::double precision THEN 'Июль '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        8::double precision THEN 'Август '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        9::double precision THEN 'Сентябрь '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        10::double precision THEN 'Октябрь '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        11::double precision THEN 'Ноябрь '::text
                   WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                        12::double precision THEN 'Декабрь '::text
                   ELSE NULL::text
                   END, date_part('year'::text,
                                  date_trunc('month'::text, smartphone_sales.order_date)::date))               AS order_period,
       sum(COALESCE(smartphone_sales.promotion_quantity, 0::bigint))                                           AS promotion_fact,
       sum(COALESCE(smartphone_sales.not_promotion_quantity, 0::bigint))                                       AS not_promotion_fact,
       avg(smartphone_sales.target_smartphones)                                                                AS not_promotion_target,
       avg(smartphone_sales.target_promotion)                                                                  AS promotion_target,
       avg(smartphone_sales.target_promotion_by_period)                                                        AS target_promotion_by_period,
       sum(smartphone_sales.order_amount_promotion)                                                            AS order_amount_promotin,
       avg(smartphone_sales.price_promotion)                                                                   AS avg_price_promotion
FROM smartphone_sales
GROUP BY smartphone_sales.region, smartphone_sales.address, smartphone_sales.supervisor,
         (smartphone_sales.order_date::date),
         (concat(
                 CASE
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          1::double precision THEN 'Январь '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          2::double precision THEN 'Февраль '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          3::double precision THEN 'Март '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          4::double precision THEN 'Апрель '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          5::double precision THEN 'Май '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          6::double precision THEN 'Июнь '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          7::double precision THEN 'Июль '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          8::double precision THEN 'Август '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          9::double precision THEN 'Сентябрь '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          10::double precision THEN 'Октябрь '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          11::double precision THEN 'Ноябрь '::text
                     WHEN date_part('month'::text, date_trunc('month'::text, smartphone_sales.order_date)::date) =
                          12::double precision THEN 'Декабрь '::text
                     ELSE NULL::text
                     END, date_part('year'::text, date_trunc('month'::text, smartphone_sales.order_date)::date)));

alter table smartphones_sales_fact_target
    owner to daniildzheparov;

