create view my_view("Супервайзер", "План ДИТ, шт", "Факт ДИТ, шт", "Прогноз ДИТ") as
SELECT combined_data.supervisor                                   AS "Супервайзер",
       sum(combined_data.target_rtk)                              AS "План ДИТ, шт",
       sum(combined_data.total_rtk)                               AS "Факт ДИТ, шт",
       (sum(combined_data.total_rtk)::double precision /
        date_part('day'::text, (SELECT max(di_successful.date_activation) AS max
                                FROM di_successful
                                WHERE di_successful.date_activation >= '2024-03-01'::date
                                  AND di_successful.date_activation <= '2024-03-14'::date)) * date_part('day'::text,
                                                                                                        max(date_trunc(
                                                                                                                    'month'::text,
                                                                                                                    combined_data.date_activation::timestamp with time zone) +
                                                                                                            '1 mon'::interval -
                                                                                                            '1 day'::interval)) /
        sum(combined_data.target_rtk)::double precision)::numeric AS "Прогноз ДИТ"
FROM (SELECT stores.supervisor,
             targets.rtk   AS target_rtk,
             NULL::integer AS total_rtk,
             NULL::date    AS date_activation
      FROM stores
               JOIN targets ON stores.posid = targets.posid
      WHERE targets.reporting_period >= '2024-03-01'::date
        AND targets.reporting_period <= '2024-03-14'::date
      UNION ALL
      SELECT stores.supervisor,
             NULL::numeric                         AS target_rtk,
             count(di_successful.orderid)::integer AS total_rtk,
             di_successful.date_activation         AS "Прогноз ДИТ"
      FROM stores
               JOIN di_successful ON stores.posid = di_successful.posid
      WHERE di_successful.date_activation >= '2024-03-01'::date
        AND di_successful.date_activation <= '2024-03-14'::date
      GROUP BY stores.supervisor, di_successful.date_activation) combined_data
GROUP BY combined_data.supervisor
ORDER BY ((sum(combined_data.total_rtk)::double precision /
           date_part('day'::text, (SELECT max(di_successful.date_activation) AS max
                                   FROM di_successful
                                   WHERE di_successful.date_activation >= '2024-03-01'::date
                                     AND di_successful.date_activation <= '2024-03-14'::date)) * date_part('day'::text,
                                                                                                           max(date_trunc(
                                                                                                                       'month'::text,
                                                                                                                       combined_data.date_activation::timestamp with time zone) +
                                                                                                               '1 mon'::interval -
                                                                                                               '1 day'::interval)) /
           sum(combined_data.target_rtk)::double precision)::numeric) DESC;

alter table my_view
    owner to postgres;

grant select on my_view to daniildzheparov;

